﻿// See https://aka.ms/new-console-template for more information
using Struct___Enums;
// Console.WriteLine("Hello User!");
// Address myAddress = new()
// {
//     City = "Abeokuta",
//     State = "Ogun State",
//     Country = "Nigeria"
// };
// foreach (var day in Enum.GetValues(typeof(DaysOfTheWeek)))
// {
//     Console.WriteLine((int)day +  ". " + day);
// }

Console.WriteLine(MonthsOfTheYear.January.State());
