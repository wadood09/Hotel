namespace Struct___Enums
{
    public enum State
    {
        IsRegular = 1,
        IsIrregular,
        IsAbnormal
    }
}